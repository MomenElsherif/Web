![alt text](https://github.com/mustafaslamv/EzSocial/blob/main/images/logo.png?raw=true)
Description:

EzSocial (easy social) is a simple one-page website help designers and all creators to know the proper resolution for their next design for the most famous social media websites.

You don’t have to search for each website to know the best resolution for your design, we give it for you on one page with a fixed position small menu that helps you to move quickly to the section of the website you need.

Also, we give you a cool feature that helps to copy any emoji you like easily, it’s helpful for people who don’t have a built-in emoji section on their keyboards
